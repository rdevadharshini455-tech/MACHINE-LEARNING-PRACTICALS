"""Train and save the Linear Regression queue-time prediction model."""

from pathlib import Path

import joblib
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split


# Using the script's folder makes the program work from any terminal location.
PROJECT_FOLDER = Path(__file__).resolve().parent
DATA_FILE = PROJECT_FOLDER / "queue_data.csv"
MODEL_FILE = PROJECT_FOLDER / "queue_model.pkl"

FEATURES = [
    "people_waiting",
    "service_counters",
    "avg_service_time",
    "current_hour",
]
TARGET = "waiting_time_minutes"


def main() -> None:
    """Load data, train the model, evaluate it, and save it."""
    print("Loading sample queue data...")
    data = pd.read_csv(DATA_FILE)

    required_columns = FEATURES + [TARGET]
    missing_columns = [column for column in required_columns if column not in data.columns]
    if missing_columns:
        raise ValueError(f"Missing CSV columns: {', '.join(missing_columns)}")

    if data[required_columns].isnull().any().any():
        raise ValueError("The CSV contains empty values. Please complete the dataset.")

    # X contains the inputs and y contains the value the model must learn.
    X = data[FEATURES]
    y = data[TARGET]

    # Keep 20% of the rows unseen so we can evaluate the trained model.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)

    test_predictions = model.predict(X_test)
    mae = mean_absolute_error(y_test, test_predictions)

    # joblib stores the trained model so app.py can reuse it.
    joblib.dump(model, MODEL_FILE)

    print("\nTraining completed successfully!")
    print(f"Total dataset rows : {len(data)}")
    print(f"Training rows      : {len(X_train)}")
    print(f"Testing rows       : {len(X_test)}")
    print(f"Mean Absolute Error: {mae:.2f} minutes")
    print(f"Model saved at     : {MODEL_FILE}")


if __name__ == "__main__":
    main()
