# AI Queue Time Predictor

A beginner-friendly Python and Machine Learning mini project that estimates a person's queue waiting time and classifies the queue as **Low**, **Moderate**, or **High**.

> **Dataset notice:** `queue_data.csv` contains simulated/sample data created only for education and demonstration. It is not collected from a real organization and should not be treated as a real-world prediction system.

## Student Details

| Field | Details |
|---|---|
| Register Number | 421124102028 |
| Name | R. Devadharshini |
| Project Title | AI Queue Time Predictor |

## Problem Statement

People often do not know how long they may need to wait at hospitals, banks, billing counters, government offices, or other service locations. A simple estimate can help people plan their time and help organizations understand queue conditions.

## Objective

To build a web application that uses a Linear Regression model to predict waiting time from the number of people waiting, number of available service counters, average service time, and current hour.

## Technologies Used

- Python
- Pandas
- Scikit-learn
- Linear Regression
- Streamlit
- CSV dataset
- Joblib for saving and loading the model

## Features

- Simple and clean Streamlit web interface
- Four easy input fields
- One-click waiting-time prediction
- Negative predictions automatically changed to zero
- Queue condition shown with a color and label
- Model evaluation using Mean Absolute Error (MAE)
- Clear error message if the model has not been trained
- Fully local: no paid API or external service

## Inputs and Output

### Inputs

1. Number of people waiting
2. Number of service counters
3. Average service time in minutes
4. Current hour in 24-hour format (`0` to `23`)

### Outputs

- Predicted waiting time in minutes
- Queue condition:
  - **Low:** 10 minutes or less
  - **Moderate:** more than 10 and up to 25 minutes
  - **High:** more than 25 minutes

## Machine Learning Algorithm

The project uses **Linear Regression**, a supervised Machine Learning algorithm. It learns a linear relationship between the four input features and the target waiting time.

In simple form:

```text
Predicted Waiting Time = Intercept + (Coefficient × Each Input Feature)
```

The model is suitable for this mini project because it is fast, beginner-friendly, easy to explain, and works well with the simulated linear-style dataset.

## Project Workflow

```text
Sample CSV Data
      ↓
Load and Separate Features/Target
      ↓
80% Training Data + 20% Testing Data
      ↓
Train Linear Regression Model
      ↓
Evaluate with Mean Absolute Error
      ↓
Save queue_model.pkl
      ↓
Streamlit App Loads Model
      ↓
User Inputs → Prediction → Queue Status
```

## Project Files

```text
AI-Queue-Time-Predictor/
├── app.py                 # Streamlit web application
├── train_model.py         # Model training and evaluation
├── queue_data.csv         # Simulated/sample dataset
├── queue_model.pkl        # Generated after model training
├── requirements.txt       # Required Python packages
└── README.md              # Project documentation
```

## Installation in VS Code

### 1. Requirements

- Install Python 3.10 or newer.
- Install Visual Studio Code.
- In VS Code, install the official **Python** extension.
- Open the `AI-Queue-Time-Predictor` folder in VS Code.

### 2. Open the VS Code terminal

Select **Terminal → New Terminal**, then confirm that the terminal is inside the project folder.

### 3. Create a virtual environment

```bash
python -m venv .venv
```

### 4. Activate the virtual environment

Windows PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run this once in the same terminal and activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Windows Command Prompt:

```cmd
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

### 5. Install dependencies (exact command)

```bash
python -m pip install -r requirements.txt
```

## How to Train the Model

Run this exact command from the project folder:

```bash
python train_model.py
```

The script loads `queue_data.csv`, creates an 80/20 train-test split, trains the Linear Regression model, prints the Mean Absolute Error, and creates `queue_model.pkl`.

## How to Run the Streamlit Application

Run this exact command after training:

```bash
python -m streamlit run app.py
```

Streamlit will normally open the application automatically at:

```text
http://localhost:8501
```

To stop the application, press `Ctrl + C` in the terminal.

## Expected Sample Output

Example inputs:

| Input | Value |
|---|---:|
| Number of people waiting | 12 |
| Number of service counters | 2 |
| Average service time | 4 minutes |
| Current hour | 14 |

Expected result:

```text
Predicted waiting time: 23.5 minutes
Queue condition: Moderate
```

This value is produced by the included trained model and fixed sample dataset.

## Upload the Project to GitHub

Create an empty repository named `AI-Queue-Time-Predictor` on GitHub. Do not add a README on the GitHub website because this project already contains one. Then run these commands inside the project folder:

```bash
git init
git add .
git commit -m "Add AI Queue Time Predictor mini project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/AI-Queue-Time-Predictor.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your real GitHub username. If Git asks you to sign in, complete the browser sign-in process.

## One-Minute Project Explanation

> Good morning. My name is R. Devadharshini, and my register number is 421124102028. My mini project is called AI Queue Time Predictor. The purpose of this project is to estimate how long a person may wait in a queue. The user enters the number of people waiting, number of service counters, average service time, and current hour. I used a simulated CSV dataset, Pandas for data handling, and Scikit-learn's Linear Regression algorithm to train the model. I divided the data into training and testing sets and evaluated the prediction using Mean Absolute Error. The trained model is saved using Joblib. A Streamlit web application loads this model and displays the predicted waiting time along with a Low, Moderate, or High queue condition. The project runs completely on a local computer and does not use any paid API. In the future, it can be improved using real-time queue data and more advanced algorithms.

## Common Viva Questions and Answers

### 1. What is the main aim of this project?

The aim is to predict a person's estimated queue waiting time from current queue information.

### 2. Why did you use Machine Learning?

Machine Learning can learn the relationship between past queue conditions and waiting time, then use that relationship to predict a new case.

### 3. Why did you choose Linear Regression?

Linear Regression is simple, fast, easy to understand, and suitable for predicting a continuous numerical value such as minutes.

### 4. What are the independent variables?

The independent variables are people waiting, service counters, average service time, and current hour.

### 5. What is the dependent or target variable?

The target variable is `waiting_time_minutes`.

### 6. What is supervised learning?

Supervised learning trains a model with input examples that already have known correct output values.

### 7. Why do you split the dataset?

The training part teaches the model, while the testing part checks its performance on data it did not use for learning.

### 8. What does the 80/20 split mean?

Eighty percent of the rows are used for training and twenty percent are used for testing.

### 9. What is Mean Absolute Error?

MAE is the average absolute difference between actual and predicted waiting times. A smaller MAE means predictions are closer to the test values.

### 10. What is the purpose of Pandas?

Pandas loads the CSV file and helps select and organize the feature and target columns.

### 11. What is Streamlit?

Streamlit is a Python framework that quickly converts a Python script into an interactive web application.

### 12. Why is Joblib used?

Joblib saves the trained model to a file and loads it later without retraining every time the application starts.

### 13. Why does the app prevent negative predictions?

A real waiting time cannot be negative. The app uses zero as the minimum valid result.

### 14. Is the dataset real?

No. It is a small simulated/sample dataset used only to demonstrate the Machine Learning workflow.

### 15. What are the limitations?

The sample dataset is small and simulated. Real queues can also be affected by staff efficiency, priority customers, breaks, service type, and unexpected delays.

### 16. Does this project use AI or an external API?

It uses a basic Machine Learning model locally. It does not use a paid API or external online service.

### 17. How is queue condition decided?

Up to 10 minutes is Low, more than 10 up to 25 minutes is Moderate, and more than 25 minutes is High.

### 18. How can the project be improved?

It can use real historical data, live token systems, time and day information, separate service types, cloud deployment, and comparison with other regression algorithms.

## Future Enhancements

- Collect real queue data from a hospital, bank, or office
- Add day of week, service type, and staff availability
- Compare Linear Regression with Random Forest and Gradient Boosting
- Store past predictions in a database
- Add charts showing busy and quiet hours
- Integrate a real token or queue management system
- Deploy the application online for public access

## Conclusion

The AI Queue Time Predictor demonstrates the complete beginner-level Machine Learning workflow: collecting data, separating features and target, training and testing a regression model, evaluating it, saving it, and using it inside a web application. It is simple enough for learning and presentation while providing a clear foundation for a future real-world queue management solution.
