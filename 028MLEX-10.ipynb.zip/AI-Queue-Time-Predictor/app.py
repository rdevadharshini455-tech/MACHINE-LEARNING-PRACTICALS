"""Streamlit web application for predicting queue waiting time."""

from pathlib import Path

import joblib
import pandas as pd
import streamlit as st


PROJECT_FOLDER = Path(__file__).resolve().parent
MODEL_FILE = PROJECT_FOLDER / "queue_model.pkl"
FEATURES = [
    "people_waiting",
    "service_counters",
    "avg_service_time",
    "current_hour",
]


st.set_page_config(
    page_title="AI Queue Time Predictor",
    page_icon="⏱️",
    layout="centered",
)


@st.cache_resource
def load_model():
    """Load the saved model once and reuse it while the app is running."""
    return joblib.load(MODEL_FILE)


def queue_status(waiting_time: float) -> tuple[str, str]:
    """Return a queue label and its matching emoji."""
    if waiting_time <= 10:
        return "Low", "🟢"
    if waiting_time <= 25:
        return "Moderate", "🟡"
    return "High", "🔴"


st.title("⏱️ AI Queue Time Predictor")
st.write(
    "Enter the current queue details to estimate how many minutes a person may wait."
)

with st.expander("Project details"):
    st.write("**Student:** R. Devadharshini")
    st.write("**Register Number:** 421124102028")
    st.write("**Algorithm:** Linear Regression")

if not MODEL_FILE.exists():
    st.error(
        "The trained model was not found. Open a terminal, run "
        "`python train_model.py`, and refresh this page."
    )
    st.stop()

try:
    model = load_model()
except Exception as error:
    st.error(f"The model could not be loaded: {error}")
    st.info("Run `python train_model.py` again to recreate the model.")
    st.stop()

st.subheader("Current queue information")

left_column, right_column = st.columns(2)

with left_column:
    people_waiting = st.number_input(
        "Number of people waiting",
        min_value=0,
        max_value=200,
        value=12,
        step=1,
        help="Count the people who are currently ahead in the queue.",
    )
    average_service_time = st.number_input(
        "Average service time (minutes)",
        min_value=0.5,
        max_value=60.0,
        value=4.0,
        step=0.5,
    )

with right_column:
    service_counters = st.number_input(
        "Number of service counters",
        min_value=1,
        max_value=50,
        value=2,
        step=1,
    )
    current_hour = st.number_input(
        "Current hour (0-23)",
        min_value=0,
        max_value=23,
        value=14,
        step=1,
        help="For example, enter 14 for 2:00 PM.",
    )

if st.button("Predict waiting time", type="primary", use_container_width=True):
    # A one-row DataFrame keeps the same feature names used during training.
    input_data = pd.DataFrame(
        [[people_waiting, service_counters, average_service_time, current_hour]],
        columns=FEATURES,
    )

    predicted_time = float(model.predict(input_data)[0])

    # A waiting time cannot be below zero, even if a model predicts it.
    predicted_time = max(0.0, predicted_time)
    status, status_emoji = queue_status(predicted_time)

    st.divider()
    st.metric("Predicted waiting time", f"{predicted_time:.1f} minutes")

    if status == "Low":
        st.success(f"{status_emoji} Queue condition: **{status}**")
    elif status == "Moderate":
        st.warning(f"{status_emoji} Queue condition: **{status}**")
    else:
        st.error(f"{status_emoji} Queue condition: **{status}**")

    st.caption(
        "This result is an educational estimate produced from simulated sample data."
    )

st.divider()
st.caption("Mini Project • Python • Scikit-learn • Streamlit")
